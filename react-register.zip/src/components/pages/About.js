const About = () => {
  return (
    <div className="about-page center_content">
      <div>
        <h1>
          <mark>About</mark> page!
        </h1>
        <p>
          This is ReactJS User Registration application. This app is created by
          using functional components with React hooks. For validating user
          details I used custom hook.
        </p>
      </div>
    </div>
  );
};

export default About;
