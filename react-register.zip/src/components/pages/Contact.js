const Contact = () => {
  return (
    <div className="contact-page center_content">
      <div>
        <h1>
          <mark>Contact</mark> page!
        </h1>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam
          quibusdam temporibus cum amet, iste accusamus quos mollitia vero, aut
          iure error nostrum. Possimus cupiditate aliquid ut et cumque, quam
          dolorum.
        </p>
      </div>
    </div>
  );
};

export default Contact;
